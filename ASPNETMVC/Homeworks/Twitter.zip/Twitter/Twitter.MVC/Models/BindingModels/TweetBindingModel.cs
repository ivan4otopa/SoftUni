﻿namespace Twitter.MVC.Models.BindingModels
{
    public class TweetBindingModel
    {
        public string Content { get; set; }
    }
}