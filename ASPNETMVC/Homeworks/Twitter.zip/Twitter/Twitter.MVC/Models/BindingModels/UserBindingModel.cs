﻿namespace Twitter.MVC.Models.BindingModels
{
    public class UserBindingModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}