﻿namespace FarmersCreed.Units
{
    using System;
    using FarmersCreed.Interfaces;
    using System.Text;

    public abstract class Animal : FarmUnit
    {
        private FoodType foodType;

        public Animal(string id, int health, int productionQuantity, ProductType productType, int healthEffect, FoodType foodType)
            : base(id, health, productionQuantity, productType, healthEffect)
        {
            this.FoodType = foodType;
        }

        public FoodType FoodType
        {
            get
            {
                return this.foodType;
            }
            set
            {
                this.foodType = value;
            }
        }

        public abstract void Eat(IEdible food, int quantity);

        public virtual void Starve()
        {
            this.Health--;
        }

        public override string ToString()
        {
            StringBuilder animal = new StringBuilder();

            animal.Append(base.ToString());
            animal.Append(this.IsAlive ? ", Health: " + this.Health : ", DEAD");

            return animal.ToString();
        }
    }
}
