﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FarmersCreed.Interfaces;

namespace FarmersCreed.Units
{
    public class Cow : Animal
    {
        private const int CowHealth = 15;
        private const int CowProductionQuantity = 6;
        private const int CowHealthEffect = 4;

        public Cow(string id)
            : base(id, CowHealth, CowProductionQuantity, ProductType.Milk, CowHealthEffect, FoodType.Organic)
        {
        }

        public override void Eat(IEdible food, int quantity)
        {
            if (food.Quantity >= quantity)
            {
                food.Quantity -= quantity;
                if (food.FoodType == FoodType.Organic)
                {
                    this.Health += food.HealthEffect * quantity;
                }
                else
                {
                    this.Health -= food.HealthEffect * quantity;
                }
            }

            else
            {
                throw new ArgumentException("Not enough food.");
            }
        }

        public override Product GetProduct()
        {
            if (this.IsAlive)
            {
                this.Health -= 2;
                string foodId = this.Id + "Product";
                return new Food(foodId, ProductType.Milk, FoodType.Organic, CowProductionQuantity, CowHealthEffect);
            }

            throw new ArgumentException("Cow is dead.");
        }

        public override void Starve()
        {
            if (this.Health > 0)
            {
                this.Health--;
            }
            else
            {
                this.IsAlive = false;
            }
        }
    }
}
