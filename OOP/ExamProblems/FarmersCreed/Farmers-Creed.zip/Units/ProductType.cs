﻿namespace FarmersCreed.Units
{
    public enum ProductType
    {
        Grain,
        Tobacco,
        Cherry,
        Milk,
        PorkMeat
    }
}
