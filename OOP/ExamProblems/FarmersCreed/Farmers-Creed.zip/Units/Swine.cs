﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FarmersCreed.Interfaces;

namespace FarmersCreed.Units
{
    public class Swine : Animal
    {
        private const int SwineHealth = 20;
        private const int SwineProductionQuantity = 1;
        private const int SwineHealthEffect = 5;

        public Swine(string id)
            : base(id, SwineHealth, SwineProductionQuantity, ProductType.PorkMeat, SwineHealthEffect, FoodType.Meat)
        {
        }

        public override void Eat(IEdible food, int quantity)
        {
            if (food.Quantity >= quantity)
            {
                food.Quantity -= quantity;
                this.Health += food.HealthEffect * 2 * quantity;
            }
            else
            {
                throw new ArgumentException("Not enough food.");
            }
        }

        public override void Starve()
        {
            if (this.Health > 0)
            {
                this.Health -= 3;
            }
            else
            {
                this.IsAlive = false;
            }
        }

        public override Product GetProduct()
        {
            if (this.IsAlive)
            {
                this.IsAlive = false;
                string foodId = this.Id + "Product";
                return new Food(foodId, ProductType.PorkMeat, FoodType.Meat, SwineProductionQuantity, SwineHealthEffect);
            }

            throw new ArgumentException("Swine is dead.");
        }
    }
}
