﻿﻿namespace FarmersCreed.Units
 {
     using System;
     using System.Text;

     public abstract class Plant : FarmUnit
     {
         private int growTime;
         private bool hasGrown = false;

         public Plant(string id, int health, int productionQuantity, int growTime, ProductType productType, int healthEffect)
             : base(id, health, productionQuantity, productType, healthEffect)
         {
             this.GrowTime = growTime;
         }

         public bool HasGrown
         {
             get
             {
                 return this.hasGrown;
             }
             set
             {
                 this.hasGrown = value;
             }
         }

         public int GrowTime
         {
             get
             {
                 return this.growTime;
             }
             set
             {
                 this.growTime = value;
             }
         }

         public virtual void Water()
         {
             this.Health += 2;
         }

         public virtual void Wither()
         {
             this.Health--;
             if (this.Health <= 0)
             {
                 this.IsAlive = false;
             }
         }

         public virtual void Grow()
         {
             if (this.GrowTime > 0)
             {
                 this.GrowTime--;
             }
             else
             {
                 this.hasGrown = true;
             }
         }

         public override string ToString()
         {
             StringBuilder plant = new StringBuilder();

             plant.Append(base.ToString());
             plant.Append(this.IsAlive ? ", Health: " + this.Health + ", Grown: " + (this.HasGrown ? "Yes" : "No") : ", DEAD");

             return plant.ToString();
         }
     }
 }