﻿namespace FarmersCreed.Units
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class Product : GameObject, IProduct
    {
        private int quantity;
        private ProductType productType;

        public Product(string id, ProductType productType, int quantity)
            : base(id)
        {
            this.Quantity = quantity;
            this.ProductType = productType;
        }

        public int Quantity
        {
            get { return this.quantity; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("Product quantity cannot be negative!");
                }
                this.quantity = value;
            }
        }

        public ProductType ProductType
        {
            get { return this.productType; }
            set { this.productType = value; }
        }

        public override string ToString()
        {
            StringBuilder product = new StringBuilder();

            string productQuantity = ", Quantity: " + this.Quantity;
            string productProductType = ", Product Type: " + this.ProductType;

            product.Append(base.ToString());
            product.Append(productQuantity);
            product.Append(productProductType);

            return product.ToString();
        }
    }
}
