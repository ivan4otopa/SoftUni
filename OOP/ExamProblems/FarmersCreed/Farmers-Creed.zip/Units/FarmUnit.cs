﻿    using FarmersCreed.Interfaces;

namespace FarmersCreed.Units
{
    using System;

    public abstract class FarmUnit : GameObject, IProductProduceable 
    {
        private int health;
        private int productionQuantity;
        private bool isAlive = true;
        private int healthEffect;

        public FarmUnit(string id, int health, int productionQuantity, ProductType productType, int healthEffect)
            : base(id)
        {  
            this.Health = health;
            this.ProductionQuantity = productionQuantity;
            this.ProductType = productType;
            this.HealthEffect = healthEffect;
        }

        public int Health
        {
            get 
            {
                return this.health;    
            }
            set
            {
                this.health = value;
            }
        }

        public bool IsAlive
        {
            get
            {
                return this.isAlive;
            }
            set
            {
                this.isAlive = value;
            }
        }

        public int ProductionQuantity
        {
            get
            {
                return this.productionQuantity;
            }
            set
            {
                this.productionQuantity = value;
            }
        }

        public ProductType ProductType { get; set; }

        public int HealthEffect
        {
            get
            {
                return this.healthEffect;
            }
            set
            {
                this.healthEffect = value;
            }
        }

        public abstract Product GetProduct();
    }
}
