﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersCreed.Units
{
    public class CherryTree : FoodPlant
    {
        private const int CherryTreeHealth = 14;
        private const int CherryTreeProductionQuantity = 4;
        private const int CherryTreeGrowTime = 3;
        private const int CherryTreeHealthEffect = 2;

        public CherryTree(string id)
            : base(id, CherryTreeHealth, CherryTreeProductionQuantity, CherryTreeGrowTime, ProductType.Cherry, 
            CherryTreeHealthEffect)
        {
        }

        public override Product GetProduct()
        {
            if (this.IsAlive)
            {
                string productId = this.Id + "Product";
                return new Food(productId, ProductType.Cherry, FoodType.Organic, CherryTreeProductionQuantity,
                    CherryTreeHealthEffect);
            }

            throw new ArgumentException("Cherry tree is dead.");
        }

        public override void Wither()
        {
            this.Health -= 2;
            if (this.Health <= 0)
            {
                this.IsAlive = false;
            }
        }
    }
}
