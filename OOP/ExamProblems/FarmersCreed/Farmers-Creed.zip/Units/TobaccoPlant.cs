﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmersCreed.Units
{
    public class TobaccoPlant : Plant
    {
        private const int TobaccoHealth = 12;
        private const int TobaccoProductionQuantity = 10;
        private const int TobaccoGrowTime = 4;
        private const int TobaccoHealthEffect = 0;

        public TobaccoPlant(string id)
            : base(id, TobaccoHealth, TobaccoProductionQuantity, TobaccoGrowTime, ProductType.Tobacco, TobaccoHealthEffect)
        {
        }

        public override void Grow()
        {
            if (this.GrowTime <= 0)
            {
                this.HasGrown = true;
            }
            else
            {
                this.GrowTime -= 2;
            }
        }

        public override Product GetProduct()
        {
            if (this.HasGrown && this.IsAlive)
            {
                string productId = this.Id + "Product";
                return new Product(productId, ProductType.Tobacco, TobaccoProductionQuantity);
            }

            throw new ArgumentException("Tobacco plant is either not grown or dead.");
        }
    }
}
