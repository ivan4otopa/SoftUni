﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FurnitureManufacturer.Models
{
    static class Validators
    {
        private const int ExactStringSize = 10;

        public static void AssertNotEmpty(string value, string propName)
        {
            if (String.IsNullOrEmpty(value))
            {
                throw new ArgumentNullException(propName, propName + "cannot be empty.");
            }
        }

        public static void AssertStringSize(string value, int minSize, string propName)
        {
            if (value.Length < minSize)
            {
                throw new ArgumentException(propName, propName + " should be at least " + minSize + " characters.");
            }
        }

        public static void AssertNotNegative(dynamic value, string propName)
        {
            if (value <= 0)
            {
                throw new ArgumentException(propName + " must be greater than 0.");   
            }
        }

        public static void AssertStringSizeExact(string value, string propName)
        {
            if (value.Length != ExactStringSize)
            {
                throw new ArgumentException(propName, propName + " must be exactly 10 symbols.");
            }
        }

        public static void AssertContentOnlyDigits(string value, string propName)
        {
            long longValue;
            if (!long.TryParse(value, out longValue))
            {
                throw new ArgumentException(propName, propName + " must consist only of digits.");
            }
        }
    }
}
