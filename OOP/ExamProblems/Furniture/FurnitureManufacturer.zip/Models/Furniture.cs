﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FurnitureManufacturer.Interfaces;

namespace FurnitureManufacturer.Models
{
    abstract class Furniture : IFurniture
    {
        private const int StringMinSize = 3;

        private string model;
        private MaterialType material;
        private decimal price;
        private decimal height;

        public Furniture(string model, MaterialType material, decimal price, decimal height)
        {
            this.Model = model;
            this.material = material;
            this.Price = price;
            this.Height = height;
        }

        public string Model
        {
            get 
            {
                return this.model;
            }
            private set 
            {
                Validators.AssertNotEmpty(value, "Model");
                
                Validators.AssertStringSize(value, StringMinSize, "Model");
                
                this.model = value;
            }
        }   

        public string Material
        {
            get 
            {
                return this.material.ToString(); 
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            set
            {
                Validators.AssertNotNegative(value, "Price");

                this.price = value;
            }
        }

        public decimal Height
        {
            get 
            {
                return this.height; 
            }
            protected set
            {
                Validators.AssertNotNegative(value, "Height");

                this.height = value;
            }
        }

        public override string ToString()
        {
            return String.Format("Type: {0}, Model: {1}, Material: {2}, Price: {3}, Height: {4}", this.GetType().Name, this.Model,
                this.Material, this.Price, this.Height);
        }
    }
}
