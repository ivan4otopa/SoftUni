﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantManager.Interfaces;

namespace RestaurantManager.Models
{
    public class Drink : Recipe, IDrink
    {
        private bool isCarbonated;

        public Drink(string name, decimal price, int calories, int quantityPerServing, int timeToPrepare, bool isCarbonated)
            : base(name, price, calories, quantityPerServing, MetricUnit.Milliliters, timeToPrepare)
        {
            this.IsCarbonated = isCarbonated;
            this.AssertDrinkCaloriesNotGreaterThan100(calories);
            this.AssertDrinkTimeToPrepareNotMoreThan20(timeToPrepare);
        }

        public bool IsCarbonated
        {
            get
            {
                return this.isCarbonated;
            }
            private set
            {
                this.isCarbonated = value;
            }
        }

        void AssertDrinkCaloriesNotGreaterThan100(int calories)
        {
            if (calories > 100)
            {
                throw new InvalidOperationException("Drink calories must not be greater than 100.");
            }
        }

        void AssertDrinkTimeToPrepareNotMoreThan20(int timeToPrepare)
        {
            if (timeToPrepare > 20)
            {
                throw new InvalidOperationException("Drink time to prepare must not be greater than 20 minutes.");
            }
        }

        public override string ToString()
        {
            StringBuilder drink = new StringBuilder();

            string drinkCarbonated = "\nCarbonated: " + (this.IsCarbonated ? "yes" : "no");

            drink.Append(base.ToString());
            drink.Append(drinkCarbonated);

            return drink.ToString();
        }
    }
}
