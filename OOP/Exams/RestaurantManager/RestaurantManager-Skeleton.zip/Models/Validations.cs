﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantManager.Models
{
    public static class Validations
    {
        public static void AssertEmptyString(string value, string propName)
        {
            if (String.IsNullOrEmpty(value))
            {
                throw new ArgumentException(propName, "The " + value + " is required.");
            }
        }

        public static void AssertNegativeNumber(dynamic value, string propName)
        {
            if (value <= 0)
            {
                throw new ArgumentException(propName, "The " + propName + " must be positive.");
            }
        }
    }
}
