﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantManager.Interfaces;

namespace RestaurantManager.Models
{
    public abstract class Recipe : IRecipe
    {
        private string name;
        private decimal price;
        private int calories;
        private int quantityPerServing;
        private int timeToPrepare;

        protected Recipe(string name, decimal price, int calories, int quantityPerServing, MetricUnit unit, int timeToPrepare)
        {
            this.Name = name;
            this.Price = price;
            this.Calories = calories;
            this.QuantityPerServing = quantityPerServing;
            this.Unit = unit;
            this.TimeToPrepare = timeToPrepare;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            private set
            {
                Validations.AssertEmptyString(value, "Recipe name");

                this.name = value;
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            private set
            {
                Validations.AssertNegativeNumber(value, "Recipe price");

                this.price = value;
            }
        }

        public int Calories
        {
            get
            {
                return this.calories;
            }
            private set
            {
                Validations.AssertNegativeNumber(value, "Recipe calories");

                this.calories = value;
            }
        }

        public int QuantityPerServing
        {
            get
            {
                return this.quantityPerServing;
            }
            private set
            {
                Validations.AssertNegativeNumber(value, "Recipe quantity per serving");

                this.quantityPerServing = value;
            }
        }

        public MetricUnit Unit { get; set; }

        public int TimeToPrepare
        {
            get
            {
                return this.timeToPrepare;
            }
            private set
            {
                Validations.AssertNegativeNumber(value, "Recipe time to prepare");

                this.timeToPrepare = value;
            }
        }

        public override string ToString()
        {
            StringBuilder recipe = new StringBuilder();

            string unitString = this.Unit == MetricUnit.Milliliters ? "ml" : "g";

            string recipeName = "==  " + this.Name;
            string recipePrice = " == $" + Math.Round(this.Price, 2);
            string recipePerServing = "Per serving: " + this.QuantityPerServing + " " + unitString + ", " + this.Calories + 
                " kcal";
            string recipeTimeToPrepare = "Ready in " + this.TimeToPrepare + " minutes";

            recipe.Append(recipeName);
            recipe.AppendLine(recipePrice);
            recipe.AppendLine(recipePerServing);
            recipe.Append(recipeTimeToPrepare);

            return recipe.ToString();
        }
    }
}
