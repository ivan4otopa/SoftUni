﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantManager.Interfaces;

namespace RestaurantManager.Models
{
    public class Salad : Meal, ISalad
    {
        private bool containsPasta;

        public Salad(string name, decimal price, int calories, int quantityPerServing, int timeToPrepare, bool containsPasta)
            : base(name, price, calories, quantityPerServing, timeToPrepare, true)
        {
            this.ContainsPasta = containsPasta;
        }

        public bool ContainsPasta
        {
            get
            {
                return this.containsPasta;
            }
            private set
            {
                this.containsPasta = value;
            }
        }

        public override string ToString()
        {
            StringBuilder salad = new StringBuilder();

            string containsPastaString = "\nContains pasta: " + (this.ContainsPasta ? "yes" : "no");

            salad.Append(base.ToString());
            salad.Append(containsPastaString);

            return salad.ToString();
        }
    }
}
