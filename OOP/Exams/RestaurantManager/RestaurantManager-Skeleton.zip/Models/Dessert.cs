﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantManager.Interfaces;

namespace RestaurantManager.Models
{
    public class Dessert : Meal, IDessert
    {
        private bool withSugar = true;

        public Dessert(string name, decimal price, int calories, int quantityPerServing, int timeToPrepare, bool isVegan,
            bool withSugar = true)
            : base(name, price,  calories, quantityPerServing, timeToPrepare, isVegan)
        {
        }

        public bool WithSugar
        {
            get
            {
                return this.withSugar;
            }
            private set
            {
                this.withSugar = value;
            }
        }

        public void ToggleSugar()
        {
            this.withSugar = !this.withSugar;
        }

        public override string ToString()
        {
            StringBuilder dessert = new StringBuilder();

            string sugar = this.WithSugar ? "" : "[NO SUGAR] ";

            dessert.Append(sugar);
            dessert.Append(base.ToString());

            return dessert.ToString();      
        }
    }
}
