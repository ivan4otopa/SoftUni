﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestaurantManager.Interfaces;

namespace RestaurantManager.Models
{
    public class Restaurant : IRestaurant
    {
        private string name;
        private string location;
        private IList<IRecipe> recipes = new List<IRecipe>();

        public Restaurant(string name, string location)
        {
            this.Name = name;
            this.Location = location;
        }

        public string Name
        {
            get 
            {
                return this.name;
            }
            private set
            {
                Validations.AssertEmptyString(value, "Restaurant name");

                this.name = value;
            }
        }

        public string Location
        {
            get
            {
                return this.location;
            }
            private set
            {
                Validations.AssertEmptyString(value, "Restaurant location");

                this.location = value;
            }
        }

        public IList<IRecipe> Recipes
        {
            get
            {
                return new List<IRecipe>(this.recipes);
            }
        }

        public void AddRecipe(IRecipe recipe)
        {
            this.recipes.Add(recipe);
        }

        public void RemoveRecipe(IRecipe recipe)
        {
            this.recipes.Remove(recipe);
        }

        public string PrintMenu()
        {
            StringBuilder restaurant = new StringBuilder();

            string restaurntName = "***** " + this.name + " - ";
            string restaurantLocation = this.location + " *****";

            restaurant.Append(restaurntName);
            restaurant.Append(restaurantLocation);

            if (this.recipes.Count == 0)
            {
                restaurant.Append("\nNo recipes... yet");

                return restaurant.ToString();
            }

            var sortedDrinks =
                from recipe in this.Recipes
                where recipe is Drink
                orderby recipe.Name
                select recipe;

            if (sortedDrinks.Count() != 0)
            {
                restaurant.Append("\n~~~~~ DRINKS ~~~~~");

                foreach (var drink in sortedDrinks)
                {
                    restaurant.Append("\n" + drink);
                }
            }

            var sortedSalads =
                from recipe in this.Recipes
                where recipe is Salad
                orderby recipe.Name
                select recipe;

            if (sortedSalads.Count() != 0)
            {
                restaurant.Append("\n~~~~~ SALADS ~~~~~");

                foreach (var salad in sortedSalads)
                {
                    restaurant.Append("\n" + salad);
                }
            }

            var sortedMainCourses =
                from recipe in this.Recipes
                where recipe is MainCourse
                orderby recipe.Name
                select recipe;

            if (sortedMainCourses.Count() != 0)
            {
                restaurant.Append("\n~~~~~ MAIN COURSES ~~~~~");

                foreach (var mainCourse in sortedMainCourses)
                {
                    restaurant.Append("\n" + mainCourse);
                }
            }

            var sortedDesserts =
                from recipe in this.Recipes
                where recipe is Dessert
                orderby recipe.Name
                select recipe;

            if (sortedDesserts.Count() != 0)
            {
                restaurant.Append("\n~~~~~ DESSERTS ~~~~~");

                foreach (var dessert in sortedDesserts)
                {
                    restaurant.Append("\n" + dessert);
                }
            }

            return restaurant.ToString();
        }
    }
}
