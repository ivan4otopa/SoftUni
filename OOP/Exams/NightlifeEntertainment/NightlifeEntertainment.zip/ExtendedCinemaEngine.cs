﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NightlifeEntertainment
{
    class ExtendedCinemaEngine : CinemaEngine
    {
        protected override void ExecuteReportCommand(string[] commandWords)
        {
            var performance = GetPerformance(commandWords[1]);
            var soldTickets =
                from ticket in performance.Tickets
                where ticket.Status == TicketStatus.Sold
                select ticket;

            int numberOfSoldTickets = soldTickets.Count();
            decimal totalPrice = CalculateTotalPrice(soldTickets);

            StringBuilder report = new StringBuilder();

            report.AppendFormat("{0}: {1} ticket(s), total: ${2:F2}", performance.Name, numberOfSoldTickets, totalPrice);
            report.AppendFormat("\nVenue: {0} ({1})", performance.Venue.Name, performance.Venue.Location);
            report.AppendFormat("\nStart time: {0}", performance.StartTime);

            this.Output.AppendLine(report.ToString());
        }

        private decimal CalculateTotalPrice(IEnumerable<ITicket> soldTickets)
        {
            decimal price = 0;
            foreach (var ticket in soldTickets)
            {
                price += ticket.Price;
            }

            return price;
        }

        protected override void ExecuteFindCommand(string[] commandWords)
        {
            string searchPhrase = commandWords[1].ToLower();
            DateTime start = DateTime.Parse(commandWords[2] + " " + commandWords[3]);

            var performanceSearchResult =
                from performance in this.Performances
                where performance.Name.ToLower().Contains(searchPhrase)
                where performance.StartTime >= start
                orderby performance.StartTime, performance.BasePrice descending, performance.Name
                select performance;

            StringBuilder searchResult = new StringBuilder();

            searchResult.AppendFormat("Search for \"{0}\"", commandWords[1]);
            searchResult.Append("\nPerformances:");

            if (performanceSearchResult.Count() == 0)
            {
                searchResult.Append("\nno results");
            }
            else
            {
                foreach (var performance in performanceSearchResult)
                {
                    searchResult.AppendFormat("\n-{0}", performance.Name);
                }
            }

            var venueSearchResult =
                from venue in this.Venues
                where venue.Name.ToLower().Contains(searchPhrase)
                orderby venue.Name
                select venue;

            searchResult.Append("\nVenues:");

            if (venueSearchResult.Count() == 0)
            {
                searchResult.Append("\nno results");
            }
            else
            {
                foreach (var venue in venueSearchResult)
                {
                    searchResult.AppendFormat("\n-{0}", venue.Name);

                    var matchingPerformances =
                        from performance in this.Performances
                        where performance.Venue.Equals(venue)
                        where performance.StartTime >= start
                        orderby performance.StartTime, performance.BasePrice descending, performance.Name
                        select performance;

                    if (matchingPerformances.Count() != 0)
                    {
                        foreach (var performance in matchingPerformances)
                        {
                            searchResult.AppendFormat("\n--{0}", performance.Name);
                        }
                    }
                }
            }

            this.Output.AppendLine(searchResult.ToString());
        }

        protected override void ExecuteInsertVenueCommand(string[] commandWords)
        {
            string venue = commandWords[2];

            switch (venue)
            {
                case "opera":
                    var opera = new OperaHall(commandWords[3], commandWords[4], int.Parse(commandWords[5]));
                    this.Venues.Add(opera);
                    break;
                case "sports_hall":
                    var sportsHall = new SportsHall(commandWords[3], commandWords[4], int.Parse(commandWords[5]));
                    this.Venues.Add(sportsHall);
                    break;
                case "concert_hall":
                    var concertHall = new ConcertHall(commandWords[3], commandWords[4], int.Parse(commandWords[5]));
                    this.Venues.Add(concertHall);
                    break;
                default:
                    base.ExecuteInsertVenueCommand(commandWords);
                    break;
            }
        }

        protected override void ExecuteInsertPerformanceCommand(string[] commandWords)
        {
            string performance = commandWords[2];

            switch (performance)
            {
                case "theatre":
                    var theatreVenue = this.GetVenue(commandWords[5]);
                    var theatre = new Theatre(commandWords[3], decimal.Parse(commandWords[4]), theatreVenue, 
                        DateTime.Parse(commandWords[6] + " " + commandWords[7]));
                    this.Performances.Add(theatre);
                    break;
                case "concert":
                    var concertVenue = this.GetVenue(commandWords[5]);
                    var concert = new Concert(commandWords[3], decimal.Parse(commandWords[4]), concertVenue,
                        DateTime.Parse(commandWords[6] + " " + commandWords[7]));
                    this.Performances.Add(concert);
                    break;
                default:
                    base.ExecuteInsertPerformanceCommand(commandWords);
                    break;
            }
        }

        protected override void ExecuteSupplyTicketsCommand(string[] commandWords)
        {
            var venue = this.GetVenue(commandWords[2]);
            var performance = this.GetPerformance(commandWords[3]);
            int ticketCount = int.Parse(commandWords[4]);
            string ticketType = commandWords[1];

            if (!this.Venues.Contains(venue) || !this.Performances.Contains(performance))
            {
                throw new ArgumentException("Not enough available seats or venu does not exist, or performance does not exist.");
            }

            switch (ticketType)
            {
                case "student":
                    for (int i = 0; i < ticketCount; i++)
                    {
                        var studentTicket = new StudentTicket(performance);
                        performance.AddTicket(studentTicket);
                    }
                    break;
                case "vip":
                    for (int i = 0; i < ticketCount; i++)
                    {
                        var vipTicket = new VIPTicket(performance);
                        performance.AddTicket(vipTicket);
                    }
                    break;  
                default:
                    base.ExecuteSupplyTicketsCommand(commandWords);
                    break;
            }
        }
    }
}
