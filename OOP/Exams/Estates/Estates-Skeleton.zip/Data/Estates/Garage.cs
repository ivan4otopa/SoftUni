﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Estates
{
    public class Garage : Estate, IGarage
    {
        private int width;
        private int height;

        public int Width
        {
            get
            {
                return this.width;
            }
            set
            {
                this.width = value;
            }
        }

        public int Height
        {
            get
            {
                return this.height;
            }
            set
            {
                this.height = value;
            }
        }

        public override string ToString()
        {
            StringBuilder garage = new StringBuilder();

            string garageWidth = " Width: " + this.width + ", ";
            string garageHeight = "Height: " + this.height;

            garage.Append(base.ToString());
            garage.Append(garageWidth);
            garage.Append(garageHeight);

            return garage.ToString(); 
        }
    }
}
