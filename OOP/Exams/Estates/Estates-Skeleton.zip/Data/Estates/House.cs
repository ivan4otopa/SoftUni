﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Estates
{
    public class House : Estate, IHouse
    {
        private int floors;

        public int Floors
        {
            get
            {
                return this.floors;
            }
            set
            {
                this.floors = value;
            }
        }

        public override string ToString()
        {
            StringBuilder house = new StringBuilder();

            string houseFloors = " Floors: " + this.floors;

            house.Append(base.ToString());
            house.Append(houseFloors);

            return house.ToString();
        }
    }
}
