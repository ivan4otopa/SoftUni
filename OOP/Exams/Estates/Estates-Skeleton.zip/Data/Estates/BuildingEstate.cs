﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Estates
{
    public abstract class BuildingEstate : Estate, IBuildingEstate
    {
        private int rooms;

        public int Rooms
        {
            get
            {
                return this.rooms;
            }
            set
            {
                this.rooms = value;
            }
        }

        public bool HasElevator { get; set; }

        public override string ToString()
        {
            StringBuilder buildingEstate = new StringBuilder();

            string buildingEstateRooms = " Rooms: " + this.rooms + ", ";
            string hasBuildingEstateGotAnElevator = "Elevator: " + (this.HasElevator ? "Yes" : "No");

            buildingEstate.Append(base.ToString());
            buildingEstate.Append(buildingEstateRooms);
            buildingEstate.Append(hasBuildingEstateGotAnElevator);

            return buildingEstate.ToString();
        }
    }
}
