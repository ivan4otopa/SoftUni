﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Estates
{
    public abstract class Estate : IEstate
    {

        private string name;
        private double area;
        private string location;

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public EstateType Type { get; set; }

        public double Area
        {
            get
            {
                return this.area;
            }
            set
            {
                this.area = value;
            }
        }

        public string Location
        {
            get
            {
                return this.location;
            }
            set
            {
                this.location = value;
            }
        }

        public bool IsFurnished { get; set; }

        public override string ToString()
        {
            StringBuilder estate = new StringBuilder();

            string estateType = this.GetType().Name + ": ";
            string estateName = "Name = " + this.name + ", ";
            string estateArea = "Area = " + this.area + ", ";
            string estateLocation = "Location = " + this.location + ", ";
            string isEstateFurnished = "Furnitured = " + (this.IsFurnished ? "Yes," : "No,");

            estate.Append(estateType);
            estate.Append(estateName);
            estate.Append(estateArea);
            estate.Append(estateLocation);
            estate.Append(isEstateFurnished);

            return estate.ToString();
        }
    }
}