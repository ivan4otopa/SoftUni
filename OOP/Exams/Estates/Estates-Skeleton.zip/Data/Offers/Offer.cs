﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Offers
{
    public abstract class Offer : IOffer
    {
        public Offer(OfferType type)
        {
            this.Type = type;
        }

        public OfferType Type { get; set; }

        public IEstate Estate { get; set; }

        public override string ToString()
        {
            StringBuilder offer = new StringBuilder();

            string offerType = this.Type + ": ";
            string offerEstateName = "Estate = " + this.Estate.Name + ", ";
            string offerEstateLocation = "Location = " + this.Estate.Location + ",";

            offer.Append(offerType);
            offer.Append(offerEstateName);
            offer.Append(offerEstateLocation);

            return offer.ToString();
        }
    }
}
