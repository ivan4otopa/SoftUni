﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Offers
{
    public class RentOffer : Offer, IRentOffer
    {
        private decimal pricePerMonth;

        public RentOffer(OfferType type)
            : base(type)
        {
        }

        public decimal PricePerMonth
        {
            get
            {
                return this.pricePerMonth;
            }
            set
            {
                this.pricePerMonth = value;
            }
        }

        public override string ToString()
        {
            StringBuilder rentOffer = new StringBuilder();

            string rentOfferPrice = " Price = " + this.pricePerMonth;

            rentOffer.Append(base.ToString());
            rentOffer.Append(rentOfferPrice);

            return rentOffer.ToString();
        }
    }
}
