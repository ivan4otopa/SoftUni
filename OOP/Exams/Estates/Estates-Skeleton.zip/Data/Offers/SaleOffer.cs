﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Estates.Interfaces;

namespace Estates.Data.Offers
{
    public class SaleOffer : Offer, ISaleOffer
    {
        private decimal price;

        public SaleOffer(OfferType type)
            : base(type)
        {
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            set
            {
                this.price = value;
            }
        }

        public override string ToString()
        {
            StringBuilder saleOffer = new StringBuilder();

            string saleOfferPrice = " Price = " + this.price;

            saleOffer.Append(base.ToString());
            saleOffer.Append(saleOfferPrice);

            return saleOffer.ToString();
        }
    }
}
