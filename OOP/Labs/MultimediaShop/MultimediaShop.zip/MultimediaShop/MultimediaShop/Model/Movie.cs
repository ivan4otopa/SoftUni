﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultimediaShop.Model
{
    class Movie : Item
    {
        public Movie(string id, string title, decimal price, int length, IList<String> genres)
            : base(id, title, price, genres)
        {
            this.Length = length;
        }

        public Movie(string id, string title, decimal price, int length, string genre)
            : this(id, title, price, length, new List<String> { genre })
        {
        }

        public int Length { get; set; }
    }
}
