﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Interfaces;

namespace MultimediaShop.Model
{
    class Item : IItem
    {
        private string id;
        private string title;
        private decimal price;

        public Item(string id, string title, decimal price, IList<String> genres)
        {
            this.Id = id;
            this.Title = title;
            this.Price = price;
            this.Genres = genres;
        }

        public Item(string id, string title, decimal price)
            : this(id, title, price, null)
        {
        }

        public string Id
        {
            get
            {
                return this.id;
            }
            set
            {
                if (String.IsNullOrEmpty(value) || value.Length < 4)
                {
                    throw new ArgumentException("Item Id cannot be null or empty or shorter than 4 symbols.");
                }
                this.id = value;
            }
        }

        public string Title
        {
            get
            {
                return this.title;
            }
            set
            {
                if (String.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Item Title cannot be null or empty.");
                }
                this.title = value;
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("Item Price cannot be a negative number.");
                }
                this.price = value;
            }
        }

        public IList<string> Genres { get; set; }

        public override string ToString()
        {
            return String.Format("{0} - {1}\nTitle: {2}\nPrice: {3}\nGenres: {4}", this.GetType().Name, this.id, this.title, this.price,
                string.Join(", ", this.Genres.Select(g => g.ToString()).ToArray()));
        }
    }
}
