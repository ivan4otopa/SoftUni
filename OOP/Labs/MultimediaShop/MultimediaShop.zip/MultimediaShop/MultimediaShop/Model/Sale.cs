﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Interfaces;
using MultimediaShop.Enums;

namespace MultimediaShop.Model
{
    class Sale : ISale
    {
        private Item item;

        public Sale(Item item, DateTime purchaseDate)
        {
            this.Item = item;
            this.PurchaseDate = purchaseDate;
        }

        public Sale(Item item)
            : this(item, DateTime.Now)
        {
        }

        public Item Item
        {
            get
            {
                return this.Item;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Sale Item cannot be null.");
                }
                this.item = value;
            }
        }

        public DateTime PurchaseDate { get; set; }

        public override string ToString()
        {
            if (this.Item.GetType().Name == "Book")
            {
                return String.Format("Sale: {0}\nAuthor: {1}", this.PurchaseDate, (this.Item as Book).Author);
            }
            else if (this.Item.GetType().Name == "Game")
            {
                return String.Format("Rent: {0}\nAge Restriction: {1}", this.PurchaseDate, (this.Item as Game).AgeRestriction);
            }
            else if (this.Item.GetType().Name == "Video")
            {
                return String.Format("Rent: {0}\nLength: {1}", this.PurchaseDate, (this.Item as Movie).Length);
            }
            return "";
        }
    }
}
