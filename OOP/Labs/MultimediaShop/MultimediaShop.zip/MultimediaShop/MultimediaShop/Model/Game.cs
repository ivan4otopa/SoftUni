﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Enums;

namespace MultimediaShop.Model
{
    class Game : Item
    {
        public Game(string id, string title, decimal price, IList<String> genres, AgeRestriction ageRestriction = AgeRestriction.Minor)
            : base(id, title, price, genres)
        {
            this.AgeRestriction = ageRestriction;
        }

        public Game(string id, string title, decimal price, string genre, AgeRestriction ageRestriction = AgeRestriction.Minor)
            : this(id, title, price, new List<String> { genre }, ageRestriction)
        {
        }

        public AgeRestriction AgeRestriction { get; set; }
    }
}
