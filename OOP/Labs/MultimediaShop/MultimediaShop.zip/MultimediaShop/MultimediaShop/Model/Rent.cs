﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Interfaces;
using MultimediaShop.Enums;

namespace MultimediaShop.Model
{
    class Rent : IRent
    {
        private Item item;
        private decimal rentFine;

        public Rent(Item item, DateTime rentDate, DateTime deadline)
        {
            this.Item = item;
            this.RentDate = rentDate;
            this.Deadline = deadline;
        }

        public Rent(Item item, DateTime rentDate)
            : this(item, rentDate, DateTime.Today.AddDays(30))
        {
        }

        public Rent(Item item)
            : this(item, DateTime.Today, DateTime.Today.AddDays(30))
        {
        }

        public Item Item
        {
            get
            {
                return this.item;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("Rent Item cannot be null.");
                }
                this.item = value;
            }
        }

        public decimal RentFine
        {
            get
            {
                return this.CalculateFine();
            }
            set
            {
                this.rentFine = value;
            }
        }

        public RentState RentState { get; set; }

        public DateTime RentDate { get; set; }

        public DateTime Deadline { get; set; }

        public DateTime ReturnDate { get; set; }

        public decimal CalculateRentFine()
        {
            throw new NotImplementedException();
        }

        public void ReturnItem()
        {
            this.RentState = RentState.Returned;
        }

        public decimal CalculateFine()
        {
            decimal fine = 0;
            int days = (DateTime.Now - this.Deadline).Days;
            if (days > 0)
            {
                fine = 0.01m * days * this.Item.Price;
            }

            return fine;
        }

        public override string ToString()
        {
            if (this.Item.GetType().Name == "Book")
            {
                return String.Format("Rent: {0}\nAuthor: {1}", this.RentState, (this.Item as Book).Author);
            }
            else if (this.Item.GetType().Name == "Game")
            {
                return String.Format("Rent: {0}\nAge Restriction: {1}", this.RentState, (this.Item as Game).AgeRestriction);
            }
            else if (this.Item.GetType().Name == "Video")
            {
                return String.Format("Rent: {0}\nLength: {1}", this.RentState, (this.Item as Movie).Length);
            }
            return "";
        }
    }
}
