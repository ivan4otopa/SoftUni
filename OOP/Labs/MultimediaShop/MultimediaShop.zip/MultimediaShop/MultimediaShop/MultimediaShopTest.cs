﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Model;
using MultimediaShop.Enums;
using MultimediaShop.Engine;

namespace MultimediaShop
{
    class MultimediaShopTest
    {
        static void Main(string[] args)
        {
            ShopEngine.Run();
        }
    }
}
