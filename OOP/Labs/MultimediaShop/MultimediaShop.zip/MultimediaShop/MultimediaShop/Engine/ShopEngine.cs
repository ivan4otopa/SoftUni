﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Model;
using MultimediaShop.Enums;
using MultimediaShop.Exceptons;
using MultimediaShop.Interfaces;

namespace MultimediaShop.Engine
{
    class ShopEngine
    {
        private static Dictionary<Item, int> supplies = new Dictionary<Item, int>();

        public static void Run()
        {
            while (true)
            {
                string input = Console.ReadLine();
                ExecuteCommand(input);
            }
        }

        private static void ExecuteCommand(string input)
        {
            string[] properties = input.Split(' ');
            string command = properties[0];

            switch (command)
            {
                case "supply":
                    AddSupplies(properties);
                    break;
                case "sell":
                    SellItem(properties);
                    break;
                case "rent":
                    RentItem(properties);
                    break;
                case "report":
                    if (properties[1] == "sales")
                    {
                        PrintSales(SaleManager.Sales, properties[2]);
                    }
                    else if (properties[1] == "rents")
                    {
                        PrintRents(RentManager.Rents);
                    }
                    break;
                default:
                    throw new ArgumentException("Invalid command.");
            }
        }

        private static void AddSupplies(string[] properties)
        {
            string item = properties[1];
            int quantity = int.Parse(properties[2]);
            Dictionary<String, String> parameters = ParseParameters(properties[3]);
            Item newItem = CreateItem(item, parameters);
            supplies.Add(newItem, quantity);
        }

        private static Dictionary<String, String> ParseParameters(string parameters)
        {
            Dictionary<String, String> keyValuePairs = new Dictionary<String, String>();
            string[] pairs = parameters.Split('&');
            foreach (var pair in pairs)
            {
                string[] keyValuePair = pair.Split('=');
                keyValuePairs[keyValuePair[0]] = keyValuePair[1];
            }

            return keyValuePairs;
        }

        private static Item CreateItem(string item, Dictionary<String, String> parameters)
        {
            string id = parameters["id"];
            string title = parameters["title"];
            decimal price = decimal.Parse(parameters["price"]);
            IList<String> genres = parameters["genre"].Split(',').ToList();

            switch (item.ToLower())
            {
                case "book":
                    string author = parameters["author"];
                    return new Book(id, title, price, author, genres);
                case "game":
                    AgeRestriction ageRestriction = AgeRestriction.Minor;
                    if (parameters["ageRestriction"] == "Adult")
                    {
                        ageRestriction = AgeRestriction.Adult;
                    }
                    else if (parameters["ageRestriction"] == "Teen")
                    {
                        ageRestriction = AgeRestriction.Teen;
                    }
                    return new Game(id, title, price, genres, ageRestriction);
                case "video":
                    int length = int.Parse(parameters["length"]);
                    return new Movie(id, title, price, length, genres);
            }

            return null;
        }

        private static void SellItem(string[] properties)
        {
            string id = properties[1];
            DateTime saleDate = DateTime.Parse(properties[2]);
            Item key = null;

            foreach (var supply in supplies)
            {
                if (supply.Key.Id == id)
                {
                    if (supply.Value == 0)
                    {
                        throw new InsufficientSuppliesException();
                    }

                    Sale sale = new Sale(supply.Key, saleDate);
                    SaleManager.AddSale(sale);
                    key = supply.Key;
                }
            }

            if (key != null)
            {
                supplies[key]--;
            }
        }

        private static void RentItem(string[] properties)
        {
            string id = properties[1];
            DateTime rentDate = DateTime.Parse(properties[2]);
            DateTime deadline = DateTime.Parse(properties[3]);
            Item key = null;

            foreach (var supply in supplies)
            {
                if (supply.Key.Id == id)
                {
                    if (supply.Value == 0)
                    {
                        throw new InsufficientSuppliesException();
                    }

                    Rent rent = new Rent(supply.Key, rentDate, deadline);
                    RentManager.AddRent(rent);
                    key = supply.Key;
                }
            }

            if (key != null)
            {
                supplies[key]--;
            }
        }

        private static void PrintSales(ISet<ISale> sales, string date)
        {
            DateTime startDate = DateTime.Parse(date);
            var salesFromDate = (from sale in sales where sale.PurchaseDate >= startDate select sale.Item.Price).Sum();

            Console.WriteLine(salesFromDate);
        }

        private static void PrintRents(ISet<IRent> rentsSet)
        {
            var rents = from rent in rentsSet where rent.RentState == RentState.Overdue orderby (rent as Rent).RentFine ascending,
                         rent.Item.Title ascending select rent;

            foreach (var rent in rents)
            {
                Console.WriteLine(rent);
            }
        }
    }
}
