﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Interfaces;

namespace MultimediaShop.Engine
{
    static class RentManager
    {
        private static ISet<IRent> rents = new HashSet<IRent>();

        public static ISet<IRent> Rents
        {
            get
            {
                return new HashSet<IRent>(rents);
            }
        }

        public static void AddRent(IRent rent)
        {
            rents.Add(rent);
        }
    }
}
