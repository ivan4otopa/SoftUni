﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultimediaShop.Exceptons
{
    class InsufficientSuppliesException : ApplicationException
    {
        public InsufficientSuppliesException()
        {
            Console.Error.WriteLine("Insufficient supplies.");
        }

        public InsufficientSuppliesException(string error)
            : base(error)
        {
        }
    }
}
