﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Model;
using MultimediaShop.Enums;

namespace MultimediaShop.Interfaces
{
    interface IRent
    {
        Item Item
        {
            get;
            set;
        }
        RentState RentState
        {
            get;
            set;
        }
        DateTime RentDate
        {
            get;
            set;
        }
        DateTime Deadline
        {
            get;
            set;
        }
        DateTime ReturnDate
        {
            get;
            set;
        }

        decimal CalculateRentFine();
    }
}
