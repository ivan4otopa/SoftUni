﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MultimediaShop.Model;

namespace MultimediaShop.Interfaces
{
    interface ISale
    {
        Item Item
        {
            get;
            set;
        }
        DateTime PurchaseDate
        {
            get;
            set;
        }
    }
}
