﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultimediaShop.Interfaces
{
    interface IItem
    {
        string Id
        {
            get;
            set;
        }
        string Title
        {
            get;
            set;
        }
        decimal Price
        {
            get;
            set;
        }
        IList<String> Genres
        {
            get;
            set;
        }
    }
}
